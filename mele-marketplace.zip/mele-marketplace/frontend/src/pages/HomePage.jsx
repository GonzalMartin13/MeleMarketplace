import React, { useState, useEffect, useCallback } from 'react';
import Navbar from '../components/Navbar.jsx';
import PostCard from '../components/PostCard.jsx';
import { api } from '../lib/api.js';
import styles from './HomePage.module.css';

export default function HomePage() {
  const [posts, setPosts] = useState([]);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchPosts = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await api.getPosts(filter === 'all' ? null : filter);
      setPosts(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [filter]);

  useEffect(() => {
    fetchPosts();
  }, [fetchPosts]);

  // Listen for new post created event
  useEffect(() => {
    const handler = () => fetchPosts();
    window.addEventListener('post-created', handler);
    return () => window.removeEventListener('post-created', handler);
  }, [fetchPosts]);

  function handleDeleted(id) {
    setPosts(prev => prev.filter(p => p.id !== id));
  }

  return (
    <div className={styles.page}>
      {/* Pass filter state up to Navbar via the re-exported Navbar wrapper */}
      <NavbarWithFilter filter={filter} onFilterChange={setFilter} />

      {/* Cork board */}
      <div className={styles.boardWrapper}>
        <div className={styles.metalFrame}>
          <div className={styles.board}>
            {/* Cork texture overlay */}
            <div className={styles.corkTexture} />

            {loading && (
              <div className={styles.stateMsg}>
                <div className={styles.spinner} />
                <span>Cargando publicaciones...</span>
              </div>
            )}

            {error && (
              <div className={styles.stateMsg} style={{ color: '#f08060' }}>
                ⚠️ {error}
              </div>
            )}

            {!loading && !error && posts.length === 0 && (
              <div className={styles.emptyMsg}>
                <p>No hay publicaciones aún.</p>
                <p style={{ fontSize: '0.85rem', marginTop: '0.4rem', opacity: 0.7 }}>
                  ¡Sé el primero en publicar algo!
                </p>
              </div>
            )}

            {!loading && !error && posts.length > 0 && (
              <div className={styles.grid}>
                {posts.map((post, i) => (
                  <div
                    key={post.id}
                    style={{ animationDelay: `${i * 0.07}s` }}
                  >
                    <PostCard post={post} onDeleted={handleDeleted} />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Internal wrapper so Navbar can receive filter props
function NavbarWithFilter({ filter, onFilterChange }) {
  return <Navbar filter={filter} onFilterChange={onFilterChange} />;
}
